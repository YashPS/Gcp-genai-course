Course Recommendation Engine

Simple course recommender that uses sentence embeddings to find similar courses based on user interests.

What it does:
- Loads course catalog from CSV
- Creates embeddings for all course descriptions 
- Takes user profile/interests as input
- Returns top 5 most similar courses using cosine similarity

Files:
- course_recommender.ipynb (main notebook)
- course_data.csv (course catalog)
- requirements.txt (dependencies)

Usage:
1. Install packages: pip install -r requirements.txt
2. Run the notebook cells in order
3. Test with the 5 sample queries provided

The notebook includes test results for all 5 sample user profiles from the assignment.