Market Sentiment Analysis

A simple tool that analyzes market sentiment for companies using LangChain and Google's Gemini AI.

What it does:
- Takes a company name
- Finds the stock ticker 
- Gets recent news articles
- Analyzes sentiment with AI
- Returns JSON with results

Requirements:
- Python 3.10+
- Google Cloud account
- Vertex AI enabled

Setup:
1. Install packages: pip install -r requirements.txt
2. Set up GCP auth: gcloud auth application-default login
3. Update PROJECT_ID in the notebook
4. Run the notebook cells

Usage:
pipeline = MarketSentimentPipeline()
result = pipeline.analyze("Apple")

The output includes company name, stock ticker, sentiment (positive/negative/neutral), confidence score, and market implications.

Files:
- market_sentiment_analyzer.ipynb (main notebook)
- README.md (this file)  
- requirements.txt (dependencies)

Run 'mlflow ui' to see experiment tracking.
